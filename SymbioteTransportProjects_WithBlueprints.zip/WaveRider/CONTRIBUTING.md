# Placeholder for CONTRIBUTING.md in WaveRider
